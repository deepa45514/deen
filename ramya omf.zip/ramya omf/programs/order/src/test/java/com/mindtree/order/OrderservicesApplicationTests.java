package com.mindtree.order;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.model.Order;
import com.mindtree.order.model.User;
import com.mindtree.order.repository.OrderRepository;
import com.mindtree.order.repository.UserRepository;
import com.mindtree.order.service.OrderService;
import com.mindtree.order.service.UserService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
@SpringBootTest
@RunWith(SpringRunner.class)
class OrderservicesApplicationTests {

	@MockBean
	OrderRepository orderRepository;
	@MockBean
	UserRepository userRepository;
	@Autowired
	UserService us;
	@Autowired
	OrderService os;
	@Test
	public void createUser() {
		User user = new User();
		user.setUserName("ramya");
		user.setUserLocation("Chennai");
		userRepository.save(user);
		
	}

	@Test
	public void updateUserOrder() {
		Order order = new Order();
		order.setQuantity(2);
		orderRepository.save(order);
	}
	
	@Test
	public void cancelOrder() {
		if(orderRepository.existsById(1)) {
			orderRepository.deleteById(1);
		}
	}
	@Test
	public void viewOrders() {
		
		when(orderRepository.findAll()).thenReturn(Stream
				.of(new Order(1, 101, 1001, 2, 820,"10.20","12/2/2021","chennai"))
				.collect(Collectors.toList()));
	}
}
