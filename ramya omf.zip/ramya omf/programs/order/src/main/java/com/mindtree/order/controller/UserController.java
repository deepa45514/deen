package com.mindtree.order.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.order.email.apidto.MailRequest;
import com.mindtree.order.email.apidto.MailResponse;
import com.mindtree.order.email.apiservice.EmailService;
import com.mindtree.order.model.Order;
import com.mindtree.order.model.User;
import com.mindtree.order.service.UserService;

@RestController
@RequestMapping("/customer")
public class UserController {

	@Autowired
	private UserService userservice;
	
	@PostMapping(value = "/orderFood")
	public ResponseEntity<String> createUser(@RequestBody User user) {
		
	  userservice.createUser(user);
	  return new ResponseEntity<String>("Food Ordered Successfully",HttpStatus.OK);
		
	}
	
	@GetMapping(value = "/viewOrderedFoods/{userId}")
	public ResponseEntity<List<Order>> viewOrders(@PathVariable int userId){
		List<Order> order= userservice.viewOrders(userId);
		 return new ResponseEntity<List<Order>>(order,HttpStatus.OK);
	}
	
	@Autowired
	private EmailService service;

	@PostMapping("/sendingEmailToDeliveryTeam")
	public ResponseEntity<String> sendEmail(@RequestBody MailRequest request) {
		Map<String, Object> model = new HashMap<>();
		model.put("Name", request.getName());
		model.put("location", request.getLocation());
		model.put("food", request.getFood());
		model.put("quantity", request.getQuantity());
		model.put("orderDate", request.getDate());
		model.put("orderTime",request.getTime());

		return new ResponseEntity<String>("Notification sent to Delivery Team",HttpStatus.OK);
}}
