package com.mindtree.order.service;

import com.mindtree.order.model.Order;

public interface OrderService {

	Order updateOrder(int id, Order order);

	String cancelOrder(int id);

}