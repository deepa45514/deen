package com.mindtree.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.order.model.Order;
import com.mindtree.order.repository.OrderRepository;
import com.mindtree.order.repository.UserRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository repository;
	
	@Override
	public Order updateOrder(int id,Order order) {
		Order exist=repository.findById(id).orElse(null);
		exist.setQuantity(order.getQuantity());
		exist.setLocation(order.getLocation());
		return repository.save(exist);
	}
	
	@Override
	public String cancelOrder(int id) {
		repository.deleteById(id);
		return "Order Cancelled Successfully";
	}
	
}
