package com.mindtree.restaurant.services;

import java.util.List;

import com.mindtree.restaurant.model.Food;
import com.mindtree.restaurant.model.Restaurant;

public interface RestaurantService {

	Restaurant addRestaurant(Restaurant restaurant);

	List<Restaurant> getRestaurantByName(String name);

	List<Restaurant> getRestaurantByLocation(String location);

	List<Restaurant> getRestaurantByDistance(double distance);

	List<Restaurant> getRestaurantByBudget(double budget);

	List<Restaurant> getRestaurantByType(String type);

	List<Food> getMenuCard(int restaurantId);

	void updateFoodStock(int foodId, int newStock);

	Food getFood(int foodId);

}