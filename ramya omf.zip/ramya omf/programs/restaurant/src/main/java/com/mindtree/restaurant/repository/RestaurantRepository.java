package com.mindtree.restaurant.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mindtree.restaurant.model.Restaurant;

@Repository
public interface RestaurantRepository extends JpaRepository<Restaurant, Integer>{

	@Query("select r from Restaurant r where r.restaurantName= :name")
	public List<Restaurant> getRestaurantByName(@Param("name") String name);
	
	@Query("select r from Restaurant r where r.location= :loc")
	public List<Restaurant> getRestaurantByLocation(@Param("loc") String location);
	
	@Query("select r from Restaurant r where r.distance= :dist")
	public List<Restaurant> getRestaurantByDistance(@Param("dist") double distance);
	
	@Query("select r from Restaurant r where r.budget= :budg")
	public List<Restaurant> getRestaurantByBudget(@Param("budg") double budget);
	
	@Query("select r from Restaurant r where r.restaurantType= :type")
	public List<Restaurant> getRestaurantByType(@Param("type") String type);
}
