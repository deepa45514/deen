package com.mindtree.restaurant.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String restaurantName;
	private String location;
	private double distance;
	private double budget;
	private String restaurantType;
	@JsonIgnoreProperties
	@OneToMany(cascade = CascadeType.ALL)
	private List<Food> food;
	public Restaurant() {
		super();
	}
	
	public Restaurant(int id, String restaurantName, String location, double distance, double budget,
			String restaurantType, List<Food> food) {
		super();
		this.id = id;
		this.restaurantName = restaurantName;
		this.location = location;
		this.distance = distance;
		this.budget = budget;
		this.restaurantType = restaurantType;
		this.food = food;
	}

	public List<Food> getFood() {
		return food;
	}

	public void setFood(List<Food> food) {
		this.food = food;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public double getBudget() {
		return budget;
	}
	public void setBudget(double budget) {
		this.budget = budget;
	}
	public String getRestaurantType() {
		return restaurantType;
	}
	public void setRestaurantType(String restaurantType) {
		this.restaurantType = restaurantType;
	}
	
	
}
