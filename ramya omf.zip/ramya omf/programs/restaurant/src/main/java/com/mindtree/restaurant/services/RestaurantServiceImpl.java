package com.mindtree.restaurant.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.restaurant.model.Food;
import com.mindtree.restaurant.model.Restaurant;
import com.mindtree.restaurant.repository.FoodRepository;
import com.mindtree.restaurant.repository.RestaurantRepository;

@Service
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	private RestaurantRepository repository;
	@Autowired
	private FoodRepository foodRepository;
	@Override
	public Restaurant addRestaurant(Restaurant restaurant) {
		return repository.save(restaurant);
	}
	
	@Override
	public List<Restaurant> getRestaurantByName(String name){
		return repository.getRestaurantByName(name);
	}
	
	@Override
	public List<Restaurant> getRestaurantByLocation(String location){
		return repository.getRestaurantByLocation(location);
	}
	
	@Override
	public List<Restaurant> getRestaurantByDistance(double distance){
		return repository.getRestaurantByDistance(distance);
	}
	
	@Override
	public List<Restaurant> getRestaurantByBudget(double budget){
		return repository.getRestaurantByBudget(budget);
	}
	
	@Override
	public List<Restaurant> getRestaurantByType(String type){
		return repository.getRestaurantByType(type);
	}
	
	@Override
	public List<Food> getMenuCard(int restaurantId){
		Restaurant restaurant=repository.findById(restaurantId).orElse(null);
		List<Food> menucard=restaurant.getFood();
		return menucard;
	}
	
	@Override
	public void updateFoodStock(int foodId,int newStock) {
		foodRepository.updateStock(foodId, newStock);
	}
	
	@Override
	public Food getFood(int foodId) {
		return foodRepository.findById(foodId).orElse(null);
	}
}
